
public class Question_3 {
	
	int[][] a;
	int R;
	int C;
	
	Question_3( int[][] a, int R, int C )
	{
		this.a = a;
		this.R = R;
		this.C = C;
	}

	public int Longest ( int nowX, int nowY, int length )
	{
		int longest = length;
		int nowHeight = a[nowX][nowY];
		if ( nowX != 0 && a[nowX-1][nowY] < nowHeight )
		{
			int tmp = Longest ( nowX-1, nowY, length+1 );
			longest = (tmp>longest)?tmp:longest;
		}
		if ( nowX != R-1 && a[nowX+1][nowY] < nowHeight)
		{
			int tmp = Longest ( nowX+1, nowY, length+1 );
			longest = (tmp>longest)?tmp:longest;
		}
		if ( nowY != 0 && a[nowX][nowY-1] < nowHeight)
		{
			int tmp = Longest ( nowX, nowY-1, length+1 );
			longest = (tmp>longest)?tmp:longest;
		}
		if ( nowY != C-1 && a[nowX][nowY+1] < nowHeight)
		{
			int tmp = Longest ( nowX, nowY+1, length+1 );
			longest = (tmp>longest)?tmp:longest;
		}
		return longest;
	}
	public static void main(String[] args)
	{
		int[][] input = {
				 {1,  2,  3,  4, 5},
				 {16, 17, 18, 19, 6},
				 {15, 24, 25, 20, 7},
				 {14, 23, 22, 21, 8},
				 {13, 12, 11, 10, 9}};

		int r=5, c=5;
		/* ��ʼ������ ������ */
		
		Question_3 ans = new Question_3( input,r,c );
		int startX=2, startY=2;
		/* ��ʼ������ */
		
		System.out.println( ans.Longest(startX, startY, 1) );
	}
}
