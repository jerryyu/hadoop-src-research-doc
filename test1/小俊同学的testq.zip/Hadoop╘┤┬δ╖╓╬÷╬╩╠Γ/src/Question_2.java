
public class Question_2 {
	
	public int pack( int[] a )
	{
		int i = 0;
		while ( !check(a) )
		{
			i++;
			newPack(a);
		}
		return i;
	}
	
	//Return true if all elements are 0
	public boolean check( int[] a )
	{
		boolean result = true;
		for( int i = 0; i < a.length; i++ )
		{
			result = result && ( a[i] == 0 );
		}
		return result;
	}
	
	private void newPack ( int[] a )
	{
		if ( a[5] != 0 )
		{
			a[5]--;
			return;
		}
		if( a[4] != 0 )
		{
			a[4]--;
			a[0] -= (a[0]<11)?a[0]:11;
			return;
		}
		if( a[3] != 0 )
		{
			a[3]--;
			int p2 = (a[1]<5)?a[1]:5;
			int remain = 20 - p2*4;
			int p1 = (remain<a[0])?remain:a[0];
			a[1] -= p2;
			a[0] -= p1;
			return;
		}
		if( a[2] != 0 )
		{
			if( a[2] >= 4 )
			{
				a[2] -= 4;
				return;
			}
			
			int remain = 36;
			
			int p3 = a[2];
			remain = 36 - p3*9;
			
			int p2_available = 0;
			switch( p3 )
			{
			case 1:
				p2_available = 5;break;
			case 2:
				p2_available = 3;break;
			case 3:
				p2_available = 1;break;
			}
			int p2 = ( a[1] < p2_available ) ? a[1] : p2_available;
			remain -= p2*4;
			int p1 = (remain<a[0])?remain:a[0];
			
			a[2] -= p3;
			a[1] -= p2;
			a[0] -= p1;
			
			return;
		}
		if( a[1] != 0 )
		{
			if(a[1]>=9)
				a[1] -= 9;
			else
			{
				int remain = 36 - 4*a[1];
				int p1 = (remain<a[0])?remain:a[0];
				
				a[1] = 0;
				a[0] -= p1;
			}
		}
		
	}
	
	public static void main(String[] args)
	{
		Question_2 ans = new Question_2();
		int[] a = { 0, 0, 4, 0, 0, 1 };
		int[] b = { 7, 5, 1, 0, 0, 0 };
		System.out.println( ans.pack(a) );
		System.out.println( ans.pack(b) );
	}

}
